//
//  SensorApp.swift
//  Sensor
//
//  Created by cmStudent on 2022/09/16.
//

import SwiftUI

@main
struct SensorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
